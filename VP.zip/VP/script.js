//The reason this, and couple other of my canvas webapps, might be laggy is because the resolution scales up directly with the size of your display. This can be fixed by programmatically adjusting based on requested page resolution..

var demos = [
  
    {
  title: "Vehicles that move",
  background: "#333333",
  dataset: {"Cars": {percentage:40, color:"#EE0000", story:"Cars are the most popular vehicle for medium range travel. They run on gasoline, which can be either diesel or regular. Gasoline, a substance originating from oil, must undergo precise treatement before it is usable fuel."},
           "Planes": {percentage:30, color:"#0000EE", story:"Planes are super fast and can fly. They are the most efficient vehicle for long distance travel. As a result, they are also the most common passenger vehicle for long distances."},
             "Boats": {percentage:20, color:"#EE7700", story:"I don't really like boats because they can cause sea-sickness. However they are useful for transporting goods and fishing."},
           "Skateboards": {percentage:10, color:"#EEEE00", story:"By far the coolest short distance vehicle. ☺"}},
  font: "Copperplate",
  fullscreen: true,
  circleRadius: 200,
  pointerRadius: 230,
  textRadius: 380,
  pointerHeadRadii: 7,
  spacing: 10*200/300
},
  
  {
  title: "Animals I Like",
  background: "#DDDDDD",
  dataset: {"koalas": {percentage:100, color:"#007744", story:"Koalas are so cute!"}},
  font: "	Papyrus",
  fullscreen: true,
  circleRadius: 300,
  pointerRadius: 335,
  textRadius: 450,
  pointerHeadRadii: 10,
  spacing: 10
},
  

  
    {
  title: "Things in my House",
  background: "#FF3322",
  dataset: {'cars':{story:'cars are sooper fun. They can drive on land but they don\'t work in aquadic conditions. :\'(',color:'#221100',percentage:35}, 'giraffes':{story:'Giraffes are sooooo cute, sometimes they fight each other with their little antenna thingies, but usually they just eat tree leaves.',color:'#0000FF',percentage:7}, 'ladybugs':{story:'lady bugs aren\'t necessarily ladies.',color:'#6600EE',percentage:55.9}, 'onion rings':{story:'Onions rings are sooo tasty, but they are soooo much better when you find one in your order of regular fries.',color:'#FFFF00',percentage:2.1}},
  font: "Copperplate",
  fullscreen: true,
  circleRadius: 200,
  pointerRadius: 230,
  textRadius: 380,
  pointerHeadRadii: 7,
  spacing: 10*200/300
},
  
];


   /*var titles = ['cars', 'giraffes', 'ladybugs', 'onion rings'];
    var stories = ['cars are sooper fun. They can drive on land but they don\'t work in aquadic conditions. :\'(', 'Giraffes are sooooo cute, sometimes they fight each other with their little antenna thingies, but usually they just eat tree leaves.', 'lady bugs aren\'t necessarily ladies.', 'Onions rings are sooo tasty, but they are soooo much better when you find one in your order of regular fries.']
    var colors = ["#FF0000", "#0000FF", "#FF00FF", "#FFFF00"];
    var ratios = [.35,.07,.559,.021];
    var spacing = 10;
    var radius = 300;
    var textRadius = 450;
    var pointerRadius = 335;
    var pointerHeadRadii = 10;*/

var settings = demos[0]


var stage;
var canvas;
var slices;
var lastCenter;

var infoPanel;
var transitionArc;
var bg;
var title;
var text;
var bar;

var demoIndex = 0;

// resize the canvas to fill browser window dynamically
function resizeCanvas() 
{
  if (settings.fullscreen)
  {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  }
  for (var i=0; i<stage.children.length; i++)
    {
      stage.children[i].x += canvas.width/2-lastCenter[0];
      stage.children[i].y += canvas.height/2-lastCenter[1];
    }
  lastCenter = [canvas.width/2, canvas.height/2];
}

function drawArc(graphics, color, center, radius,s,e) {     
    var stroke = graphics
	.beginFill(color).moveTo(center[0],center[1])
	.arc(0,0, radius, s, e).command;
	return stroke;
}

function distance(a,b)
{
  return Math.pow(Math.pow(a[0]-b[0],2)+Math.pow(a[1] - b[1],2), .5);
}

function nextDemo()
{
  demoIndex = (demoIndex+1)%demos.length;
  settings = demos[demoIndex];
  for (var i in slices.children)
    {
      slices.children[i].off('mouseover', slices.children[i].mo);
      slices.children[i].off('mouseout', slices.children[i].ml);
      slices.children[i].off('click', slices.children[i].mc);
    }
  init();
  //console.debug("hi")
}

function init() 
{
    
    stage = new createjs.Stage("PieChart1");
    canvas = document.getElementById('PieChart1');
    window.addEventListener('resize', resizeCanvas, false);
  
    canvas.style.background = settings.background;

    createjs.Ticker.setFPS(60);
  
    stage.enableMouseOver();
  
    createjs.Ticker.addEventListener("tick", stage);
    createjs.Ticker.addEventListener("tick", update);
    lastCenter = [canvas.width/2, canvas.height/2];
    resizeCanvas();
  
    slices = new createjs.Container();
    infoPanel = new createjs.Container();

    var title = new createjs.Text(settings.title, "72px "+settings.font, colourIsLight(settings.background) ? "#000" : "#FFF");
    title.x = canvas.width/4;
    title.y = 100;
    title.textAlign = "center"; 
    stage.addChild(title)

  
    //stage.update();
    /*var titles = ['cars', 'giraffes', 'ladybugs', 'onion rings'];
    var stories = ['cars are sooper fun. They can drive on land but they don\'t work in aquadic conditions. :\'(', 'Giraffes are sooooo cute, sometimes they fight each other with their little antenna thingies, but usually they just eat tree leaves.', 'lady bugs aren\'t necessarily ladies.', 'Onions rings are sooo tasty, but they are soooo much better when you find one in your order of regular fries.']
    var colors = ["#FF0000", "#0000FF", "#FF00FF", "#FFFF00"];
    var ratios = [.35,.07,.559,.021];
    var spacing = 10;
    var radius = 300;
    var textRadius = 450;
    var pointerRadius = 335;
    var pointerHeadRadii = 10;*/
    
    //
    //colourIsLight(settings.background) ? "#000" : "#FFF"
  
    var currentAngle=0;
    for (var entry in settings.dataset)
      {
        var data = settings.dataset[entry];
        if (data.percentage==100)
           settings.spacing = 0;
        var arc = new createjs.Shape();     
        arc.x = canvas.width/2;
        arc.y = canvas.height/2;
        var cAngle = currentAngle+Math.PI*data.percentage/100;
        var center = [settings.spacing*(Math.cos(cAngle)), settings.spacing*Math.sin(cAngle)]
        var label = new createjs.Text('  ' + entry + ' (' + parseInt(10*data.percentage)/10 + '%)  ', "20px "+settings.font, colourIsLight(settings.background) ? "#000" : "#FFF");
        label.x = arc.x+settings.textRadius*Math.cos(cAngle);
        label.y = arc.y+settings.textRadius*Math.sin(cAngle);
        label.textAlign = "center";
        var line = new createjs.Shape();
        line.graphics.beginStroke(colourIsLight(settings.background) ? "#000" : "#FFF").setStrokeStyle(2).moveTo(label.x-label.getMeasuredWidth()/2,5+label.y+label.getMeasuredHeight()).lineTo(label.x+label.getMeasuredWidth()/2,5+label.y+label.getMeasuredHeight())
        //branch from right side
        
        if (distance([label.x+label.getMeasuredWidth()/2,5+label.y+label.getMeasuredHeight()], [arc.x,arc.y])>distance([label.x-label.getMeasuredWidth()/2,5+label.y+label.getMeasuredHeight()], [arc.x,arc.y]))
           line.graphics.moveTo(label.x-label.getMeasuredWidth()/2,5+label.y+label.getMeasuredHeight()) //branch from left side
        line.graphics.lineTo(arc.x+settings.pointerRadius*Math.cos(cAngle), arc.y+settings.pointerRadius*Math.sin(cAngle));
line.graphics.moveTo(arc.x+settings.pointerRadius*Math.cos(cAngle)+settings.pointerHeadRadii,arc.y+settings.pointerRadius*Math.sin(cAngle)).beginFill(settings.background).drawCircle(arc.x+settings.pointerRadius*Math.cos(cAngle),arc.y+settings.pointerRadius*Math.sin(cAngle),settings.pointerHeadRadii)
        stage.addChild(line);
        //label.x-label.getMeasuredWidth()/2;
        stage.addChild(label);
                //The following are properties added to the Shape objects so it "remembers" important details about its associated graphics object, and details about the Slice data
        
        arc.color = data.color;
        arc.startAngle = currentAngle+settings.spacing/settings.circleRadius;
        arc.endAngle = currentAngle+2*Math.PI*data.percentage/100;
        arc.center = center;
        arc.title = entry;
        arc.story = data.story;
        
        var stroke = drawArc(arc.graphics, data.color, center, settings.circleRadius,0,0);
        createjs.Tween.get(stroke)
          .to({startAngle:currentAngle+settings.spacing/settings.circleRadius, endAngle:currentAngle+2*Math.PI*data.percentage/100}, 1000, createjs.Ease.sineInOut);
        currentAngle = currentAngle+2*Math.PI*data.percentage/100;
        arc.saveEvents = function(n,a,b,c){n.mo=a;n.ml=b;n.mc=c;}
        createjs.Tween.get(arc).wait(1000).call(
          function(event){
            event.target.saveEvents(event.target, event.target.on("mouseover", sliceMouseOver), event.target.on("mouseout", sliceMouseOut), event.target.on("click", sliceMouseClick));
          });
        
        //console.log(arc);
        slices.addChild(arc);
      }
  
      stage.addChild(slices);
  
    //stage.on("stagemousemove", mouseOver);
  
    stage.update();
    /*createjs.Tween.get(circle, { loop: true })
        .to({ x: 400 }, 1000, createjs.Ease.getPowInOut(4))
        .to({ alpha: 0, y: 125 }, 500, createjs.Ease.getPowInOut(2))
        .to({ alpha: 0, y: 75 }, 100)
        .to({ alpha: 1, y: 100 }, 500, createjs.Ease.getPowInOut(2))
        .to({ x: 100 }, 800, createjs.Ease.getPowInOut(2));*/
}
init();
//use globalized radius below (replace 300)

function sliceMouseOver(event)
{
event.target.filters = [
     new createjs.ColorFilter(1,1,1,1, 100,100,100,0)
];
 event.target.cache(-300, -300, 600, 600);
}

function sliceMouseOut(event)
{
event.target.filters = [
     new createjs.ColorFilter(1,1,1,1,0,0,0,0)
];
 event.target.cache(-300, -300, 600, 600);
}

function hexToRgb(hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

function colourIsLight (h) {
  
  // Counting the perceptive luminance
  // human eye favors green color...
  var rgb = hexToRgb(h);
  var a = 1 - (0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b) / 255;
  return (a < 0.5);
}

function sliceMouseClick(event)
{
    if (!stage.contains(infoPanel))
    {
    //stage.setChildIndex( event.target, stage.getNumChildren()-1);
    infoPanel.children = [];
    bg = new createjs.Shape();
    bg.graphics.beginFill(event.target.color).drawRect(0,0,canvas.width,canvas.height);
    infoPanel.addChild(bg);
    transitionArc = new createjs.Shape();
    transitionArc.x = canvas.width/2;
    transitionArc.y = canvas.height/2;
    infoPanel.parentSlice = event.target;
    var stroke = drawArc(transitionArc.graphics, "#000", [0,0], settings.circleRadius, event.target.startAngle, event.target.endAngle);
    createjs.Tween.get(stroke)
          .to({startAngle:0, endAngle:2*Math.PI, radius:Math.max(canvas.width,canvas.height)*Math.sqrt(2)}, 1000, createjs.Ease.sineInOut);
    var backButton = new createjs.Shape().set({x:60, y:60});
    backButton.graphics.beginStroke(colourIsLight(event.target.color) ? "#000" : "#FFF").setStrokeStyle(6, 'round').drawCircle(0,0,40).moveTo(-15,0).lineTo(5,20).moveTo(-15,0).lineTo(5,-20);
      
  update();
      
      
  var hit = new createjs.Shape();
  hit.graphics.beginFill("#000").drawCircle(0,0,40);
  backButton.hitArea = hit;
  backButton.color = colourIsLight(event.target.color) ? "#000" : "#FFF";
  backButton.on("mouseover", BBMouseOver);
  backButton.on("mouseout", BBMouseOut);
  backButton.on("click", BBMouseClick);
  infoPanel.addChild(backButton);
  title = new createjs.Text(event.target.title, "72px "+settings.font, backButton.color);
  title.textAlign = "center";
  title.y = 30;
  title.x = canvas.width/2;
  infoPanel.addChild(title);
  text = new createjs.Text(event.target.story, "36px "+settings.font, backButton.color);
  text.textAlign = "center";
  text.y = 150;
  text.x = canvas.width/2;
  text.lineWidth = canvas.width-50;
  infoPanel.addChild(text);
  bar = new createjs.Shape();
  bar.graphics.beginStroke(colourIsLight(event.target.color) ? "#000" : "#FFF").setStrokeStyle(3, 'round').moveTo(-canvas.width/2+150,0).lineTo(canvas.width/2-150,0)
  bar.x = canvas.width/2;
  bar.y = 125;
  infoPanel.addChild(bar);
  stage.addChild(infoPanel);
    }
}

function BBMouseOver(event)
{
  event.target.filters = [
     new createjs.ColorFilter(1,1,1,1,event.target.color=="#000"?100:-100,event.target.color=="#000"?100:-100,event.target.color=="#000"?100:-100,0)
];
 event.target.cache(-45, -45, 90, 90);
}

function BBMouseOut(event)
{
    event.target.filters = [
     new createjs.ColorFilter(1,1,1,1,0,0,0,0)
];
 event.target.cache(-45, -45, 90, 90);
}

function BBMouseClick(event)
{
    //stage.removeChild(infoPanel);
    transitionArc = new createjs.Shape();
    transitionArc.x = canvas.width/2;
    transitionArc.y = canvas.height/2;
    //stage.addChild(transitionArc);
    var stroke = drawArc(transitionArc.graphics, event.target.parent.parentSlice.color, event.target.parent.parentSlice.center, Math.max(canvas.width,canvas.height)*Math.sqrt(2), 0, 2*Math.PI);
  
  //var stroke = drawArc(arc.graphics, event.target.color, [0,0], 300, event.target.startAngle, event.target.endAngle);
    createjs.Tween.get(stroke)
          .to({startAngle:event.target.parent.parentSlice.startAngle, endAngle:event.target.parent.parentSlice.endAngle, radius:settings.circleRadius}, 1000, createjs.Ease.sineInOut).call(function(){stage.removeChild(infoPanel);});
}

function update()
{
    if (transitionArc && infoPanel)
      {
      transitionArc.x = canvas.width/2;
      transitionArc.y = canvas.height/2;
      bg.graphics.drawRect(0,0,canvas.width,canvas.height);
      
      if (title && text && bar)
      {
      title.y = 30;
      title.x = canvas.width/2;
      text.y = 150;
      text.x = canvas.width/2;
      bar.x = canvas.width/2;
      bar.y = 125;
      }
        
      infoPanel.x = infoPanel.y = 0;
      transitionArc.cache(-canvas.width/2, -canvas.height/2, canvas.width, canvas.height);
			transitionArc.updateCache();
      maskFilter = new createjs.AlphaMaskFilter(transitionArc.cacheCanvas);
      infoPanel.filters = [maskFilter];
      infoPanel.cache(0, 0, canvas.width, canvas.height);
      infoPanel.updateCache(0, 0, canvas.width, canvas.height);
      }
    /*for (var i=0; i<slices.children.length; i++)
      {
        slices.children[i].x = canvas.width/2;
        slices.children[i].y = canvas.height/2;
      }*/
}